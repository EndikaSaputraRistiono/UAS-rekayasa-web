<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\SiswaController;
use App\Http\Controllers\GuruController;
use App\Http\Controllers\KelasController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {

    // ===== SISWA =====
    Route::post('/siswa/create', [SiswaController::class, 'create']);
    Route::get('/siswa/read', [SiswaController::class, 'read']);
    Route::post('/siswa/update', [SiswaController::class, 'update']);
    Route::post('/siswa/delete', [SiswaController::class, 'delete']);

    // ===== GURU =====
    Route::post('/guru/create', [GuruController::class, 'create']);
    Route::get('/guru/read', [GuruController::class, 'read']);
    Route::post('/guru/update', [GuruController::class, 'update']);
    Route::post('/guru/delete', [GuruController::class, 'delete']);

    // ===== KELAS =====
    Route::post('/kelas/create', [KelasController::class, 'create']);
    Route::get('/kelas/read', [KelasController::class, 'read']);
    Route::post('/kelas/update', [KelasController::class, 'update']);
    Route::post('/kelas/delete', [KelasController::class, 'delete']);

    // (Opsional)
    Route::post('/logout', [AuthController::class, 'logout']);
});
