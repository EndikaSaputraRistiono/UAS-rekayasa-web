<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kelas;

class KelasController extends Controller
{
    public function create(Request $request)
    {
        $kelas = Kelas::create([
            'nama_kelas' => $request->nama_kelas,
            'wali_kelas' => $request->wali_kelas,
        ]);

        return response()->json([
            'message' => 'Data kelas berhasil ditambahkan',
            'data' => $kelas
        ]);
    }

    public function read()
    {
        return response()->json(Kelas::all());
    }

    public function update(Request $request)
    {
        $kelas = Kelas::find($request->id);

        if (!$kelas) {
            return response()->json(['message' => 'Data tidak ditemukan'], 404);
        }

        $kelas->update($request->all());

        return response()->json([
            'message' => 'Data kelas berhasil diupdate',
            'data' => $kelas
        ]);
    }

    public function delete(Request $request)
    {
        $kelas = Kelas::find($request->id);

        if (!$kelas) {
            return response()->json(['message' => 'Data tidak ditemukan'], 404);
        }

        $kelas->delete();

        return response()->json([
            'message' => 'Data kelas berhasil dihapus'
        ]);
    }
}
