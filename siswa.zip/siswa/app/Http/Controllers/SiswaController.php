<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;

class SiswaController extends Controller
{
    public function create(Request $request)
    {
        $siswa = Siswa::create([
            'nama'   => $request->nama,
            'nis'    => $request->nis,
            'alamat' => $request->alamat,
        ]);

        return response()->json([
            'message' => 'Data siswa berhasil ditambahkan',
            'data' => $siswa
        ]);
    }

    public function read()
    {
        return response()->json(Siswa::all());
    }

    public function update(Request $request)
    {
        $siswa = Siswa::find($request->id);

        if (!$siswa) {
            return response()->json(['message' => 'Data tidak ditemukan'], 404);
        }

        $siswa->update($request->all());

        return response()->json([
            'message' => 'Data siswa berhasil diupdate',
            'data' => $siswa
        ]);
    }

    public function delete(Request $request)
    {
        $siswa = Siswa::find($request->id);

        if (!$siswa) {
            return response()->json(['message' => 'Data tidak ditemukan'], 404);
        }

        $siswa->delete();

        return response()->json([
            'message' => 'Data siswa berhasil dihapus'
        ]);
    }
}
