<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Guru;

class GuruController extends Controller
{
    public function create(Request $request)
    {
        $guru = Guru::create([
            'nama'  => $request->nama,
            'nip'   => $request->nip,
            'mapel' => $request->mapel,
        ]);

        return response()->json([
            'message' => 'Data guru berhasil ditambahkan',
            'data' => $guru
        ]);
    }

    public function read()
    {
        return response()->json(Guru::all());
    }

    public function update(Request $request)
    {
        $guru = Guru::find($request->id);

        if (!$guru) {
            return response()->json(['message' => 'Data tidak ditemukan'], 404);
        }

        $guru->update($request->all());

        return response()->json([
            'message' => 'Data guru berhasil diupdate',
            'data' => $guru
        ]);
    }

    public function delete(Request $request)
    {
        $guru = Guru::find($request->id);

        if (!$guru) {
            return response()->json(['message' => 'Data tidak ditemukan'], 404);
        }

        $guru->delete();

        return response()->json([
            'message' => 'Data guru berhasil dihapus'
        ]);
    }
}
